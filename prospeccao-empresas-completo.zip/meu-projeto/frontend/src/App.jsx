import { useState } from 'react'
import { Button } from '@/components/ui/button.jsx'
import { Input } from '@/components/ui/input.jsx'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card.jsx'
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table.jsx'
import { Badge } from '@/components/ui/badge.jsx'
import { Checkbox } from '@/components/ui/checkbox.jsx'
import { Search, Download, MapPin, Phone, Building } from 'lucide-react'
import './App.css'

function App() {
  const [city, setCity] = useState('')
  const [businesses, setBusinesses] = useState([])
  const [loading, setLoading] = useState(false)
  const [showOnlyNotOnMaps, setShowOnlyNotOnMaps] = useState(false)
  const [error, setError] = useState('')

  const searchBusinesses = async () => {
    if (!city.trim()) {
      setError('Por favor, digite o nome de uma cidade')
      return
    }

    setLoading(true)
    setError('')
    
    try {
      // Usar localhost para desenvolvimento, ou a URL da API em produção
      const apiUrl = process.env.NODE_ENV === 'production' 
        ? 'https://8xhpiqcvjzkg.manus.space/api/search' 
        : 'http://localhost:5000/api/search'
      
      const response = await fetch(`${apiUrl}?city=${encodeURIComponent(city)}`)
      const data = await response.json()
      
      if (!response.ok) {
        throw new Error(data.error || 'Erro ao buscar empresas')
      }
      
      setBusinesses(data.businesses || [])
    } catch (err) {
      setError(err.message)
      setBusinesses([])
    } finally {
      setLoading(false)
    }
  }

  const exportToCSV = () => {
    const filteredBusinesses = showOnlyNotOnMaps 
      ? businesses.filter(b => !b.is_on_maps)
      : businesses

    if (filteredBusinesses.length === 0) {
      alert('Nenhuma empresa para exportar')
      return
    }

    const headers = ['Nome', 'Endereço', 'Telefone', 'No Google Maps']
    const csvContent = [
      headers.join(','),
      ...filteredBusinesses.map(business => [
        `"${business.name}"`,
        `"${business.address}"`,
        `"${business.phone}"`,
        business.is_on_maps ? 'Sim' : 'Não'
      ].join(','))
    ].join('\n')

    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' })
    const link = document.createElement('a')
    const url = URL.createObjectURL(blob)
    link.setAttribute('href', url)
    link.setAttribute('download', `empresas_${city.replace(/\s+/g, '_')}.csv`)
    link.style.visibility = 'hidden'
    document.body.appendChild(link)
    link.click()
    document.body.removeChild(link)
  }

  const filteredBusinesses = showOnlyNotOnMaps 
    ? businesses.filter(b => !b.is_on_maps)
    : businesses

  return (
    <div className="min-h-screen bg-background p-4">
      <div className="max-w-6xl mx-auto space-y-6">
        {/* Header */}
        <Card>
          <CardHeader className="text-center">
            <CardTitle className="flex items-center justify-center gap-2 text-2xl">
              <Building className="h-6 w-6" />
              Prospecção de Empresas Locais
            </CardTitle>
            <CardDescription>
              Encontre empresas que ainda não estão cadastradas no Google Maps
            </CardDescription>
          </CardHeader>
        </Card>

        {/* Search Form */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Search className="h-5 w-5" />
              Buscar Empresas
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex gap-4">
              <Input
                placeholder="Digite o nome da cidade (ex: Ijuí, RS)"
                value={city}
                onChange={(e) => setCity(e.target.value)}
                onKeyPress={(e) => e.key === 'Enter' && searchBusinesses()}
                className="flex-1"
              />
              <Button 
                onClick={searchBusinesses}
                disabled={loading}
                className="min-w-[120px]"
              >
                {loading ? 'Buscando...' : 'Buscar'}
              </Button>
            </div>
            {error && (
              <div className="mt-4 p-3 bg-destructive/10 border border-destructive/20 rounded-md">
                <p className="text-destructive text-sm">{error}</p>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Results */}
        {businesses.length > 0 && (
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle className="flex items-center gap-2">
                  <MapPin className="h-5 w-5" />
                  Resultados ({filteredBusinesses.length} empresas)
                </CardTitle>
                <div className="flex items-center gap-4">
                  <div className="flex items-center space-x-2">
                    <Checkbox
                      id="filter"
                      checked={showOnlyNotOnMaps}
                      onCheckedChange={setShowOnlyNotOnMaps}
                    />
                    <label htmlFor="filter" className="text-sm font-medium">
                      Mostrar apenas empresas não cadastradas
                    </label>
                  </div>
                  <Button
                    onClick={exportToCSV}
                    variant="outline"
                    size="sm"
                    className="flex items-center gap-2"
                  >
                    <Download className="h-4 w-4" />
                    Exportar CSV
                  </Button>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <div className="rounded-md border">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Nome</TableHead>
                      <TableHead>Endereço</TableHead>
                      <TableHead className="flex items-center gap-2">
                        <Phone className="h-4 w-4" />
                        Telefone
                      </TableHead>
                      <TableHead>Status Google Maps</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredBusinesses.map((business, index) => (
                      <TableRow key={index}>
                        <TableCell className="font-medium">
                          {business.name}
                        </TableCell>
                        <TableCell className="max-w-xs truncate">
                          {business.address}
                        </TableCell>
                        <TableCell>
                          {business.phone}
                        </TableCell>
                        <TableCell>
                          <Badge 
                            variant={business.is_on_maps ? "default" : "destructive"}
                          >
                            {business.is_on_maps ? 'No Maps' : 'Não cadastrada'}
                          </Badge>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
              
              {filteredBusinesses.length === 0 && showOnlyNotOnMaps && (
                <div className="text-center py-8 text-muted-foreground">
                  Nenhuma empresa não cadastrada encontrada
                </div>
              )}
            </CardContent>
          </Card>
        )}

        {/* Instructions */}
        <Card>
          <CardHeader>
            <CardTitle>Como usar</CardTitle>
          </CardHeader>
          <CardContent className="space-y-2 text-sm text-muted-foreground">
            <p>1. Digite o nome de uma cidade no campo de busca</p>
            <p>2. Clique em "Buscar" para encontrar empresas locais</p>
            <p>3. Use o filtro para ver apenas empresas não cadastradas no Google Maps</p>
            <p>4. Exporte os resultados em CSV para análise posterior</p>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}

export default App

