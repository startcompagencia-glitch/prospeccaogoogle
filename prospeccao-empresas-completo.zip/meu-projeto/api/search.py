from flask import Flask, request, jsonify
from flask_cors import CORS
import requests
import os

app = Flask(__name__)
CORS(app)

@app.route('/api/search', methods=['GET'])
def search_businesses():
    try:
        city = request.args.get('city')
        if not city:
            return jsonify({'error': 'Parâmetro city é obrigatório'}), 400
        
        # Obter chave da API do Google Places
        api_key = os.environ.get('GOOGLE_API_KEY')
        if not api_key:
            return jsonify({'error': 'GOOGLE_API_KEY não configurada'}), 500
        
        # Buscar empresas usando Google Places API Text Search
        places_url = 'https://maps.googleapis.com/maps/api/place/textsearch/json'
        
        # Buscar empresas locais na cidade especificada
        query = f"empresas em {city}"
        
        params = {
            'query': query,
            'key': api_key,
            'language': 'pt-BR',
            'region': 'br'
        }
        
        response = requests.get(places_url, params=params)
        data = response.json()
        
        if response.status_code != 200:
            return jsonify({'error': 'Erro ao consultar Google Places API'}), 500
        
        businesses = []
        for place in data.get('results', []):
            # Verificar se tem informações básicas
            name = place.get('name', 'Nome não disponível')
            address = place.get('formatted_address', 'Endereço não disponível')
            place_id = place.get('place_id', '')
            
            # Buscar detalhes adicionais do lugar para obter telefone
            details_url = 'https://maps.googleapis.com/maps/api/place/details/json'
            details_params = {
                'place_id': place_id,
                'fields': 'formatted_phone_number,business_status',
                'key': api_key,
                'language': 'pt-BR'
            }
            
            details_response = requests.get(details_url, params=details_params)
            details_data = details_response.json()
            
            phone = 'Não disponível'
            if details_response.status_code == 200 and 'result' in details_data:
                phone = details_data['result'].get('formatted_phone_number', 'Não disponível')
            
            # Assumir que se está na API do Google Places, está no Maps
            # Para uma implementação mais robusta, seria necessário verificar
            # se o negócio está realmente visível no Maps
            is_on_maps = True
            
            businesses.append({
                'name': name,
                'address': address,
                'phone': phone,
                'place_id': place_id,
                'is_on_maps': is_on_maps
            })
        
        return jsonify({
            'success': True,
            'businesses': businesses,
            'total': len(businesses)
        })
        
    except Exception as e:
        return jsonify({'error': f'Erro interno: {str(e)}'}), 500

@app.route('/api/health', methods=['GET'])
def health_check():
    return jsonify({'status': 'OK', 'message': 'API funcionando corretamente'})

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)

